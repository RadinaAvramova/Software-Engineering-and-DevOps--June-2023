# MVC App with Integration Tests

![mocha-tests](https://github.com/nakov/MVC-app-integration-tests-example-mocha/workflows/mocha-tests/badge.svg)

Integration tests of Web MVC app with Mocha, running in GitHub actions.

Production @ Heroku: https://nakov-mvc-node-app.herokuapp.com

Live demo at https://repl.it/@nakov/MVC-app-integration-tests-example-mocha

GitHub: https://github.com/nakov/MVC-app-integration-tests-example-mocha

Test results: https://github.com/nakov/MVC-app-integration-tests-example-mocha/actions


